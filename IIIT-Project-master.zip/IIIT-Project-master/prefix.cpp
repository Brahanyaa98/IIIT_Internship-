#include<stdio.h>
#include<stdlib.h>
int prfxSum()
{
    int *x=0;
    int *y=0;
    int sum=0;
    int num=0;
    int i=0;

    printf("Enter number of elements in an array:\n");
    scanf("%d",&num);

    x = new int[num];
    y = new int[num];

    while(i < num)
    {
        printf("Enter element " ,i+1);
        scanf("%d",&x[i++]);
    }

     printf("Output Array:\n");
    i = 0;
    while(i < num)
    {
        sum += x[i];
        y[i] = sum;
        printf("%d",y[i++]);
    }

    return 0;
}